<?php
include("../dbconfig.php"); 
extract($_POST);
if(isset($sub))
{
$user=$_SESSION['user'];
$facultyd=$_POST['facultyd']; 
	
$sql=mysqli_query($conn,"select * from feedback_ans where faculty='$facultyd' and student_id='$user'");
$r=mysqli_num_rows($sql);

if($r==true)
{
echo "<h2 style='color:red'>You already given feedback to this faculty</h2>";
}
else
{
	$semester=$_POST['semesterd']; 
	//echo $semester;
    
	$subjectd=$_POST['subjectd']; 
	// $subjectd;
	$facultyd=$_POST['facultyd']; 
	//echo $facultyd;
$query="insert into feedback_ans values('','$semesterd','$subjectd','$facultyd','$user','$q_1','$q_2','$q_3','$q_4','$q_5','$q_6','$sugg',now())";

mysqli_query($conn,$query);

echo "<h2 style='color:green'>Thank you </h2>";
}



}


?>

<form method="post" id="frm">
<fieldset>
<center><u>FeedBack Form</u></center><br>
 
<fieldset>



<h3>Students are requested to give feedback appropriately:</h3>
1

<button type="button" style="font-size:7pt;color:white;background-color:green;border:2px solid #336600;padding:3px">Strongly Agree 5</button>
<button type="button" style="font-size:7pt;color:white;background-color:Brown;border:2px solid #336600;padding:3px">Agree 4</button>
<button type="button" style="font-size:7pt;color:white;background-color:blue;border:2px solid #336600;padding:3px">Neutral 3</button>
<button type="button" style="font-size:7pt;color:white;background-color:Black;border:2px solid #336600;padding:3px"> Disagree 2</button>
<button type="button" style="font-size:7pt;color:white;background-color:red;border:2px solid #336600;padding:3px">Strongly Disagree 1</button><br>

<table class="table table-bordered" style="margin-top:50px">


<tr>

<th> Select semester::</th>
<td>
<select id="semester" name="semesterd" class="form-control" >
	
<?php	
$sql=mysqli_query($conn,"select distinct semester from sub_master");
$sem_ans=$sql;

	while($r=mysqli_fetch_array($sql))
	{
	echo "<option value='".$r['semester']."'>".$r['semester']."</option>";
	}
		 ?>
</select>
</td>
</tr>

 <tr>

<th> Select subject::</th>
<td>
<select name="subjectd" class="form-control">
	<?php

	//$qstring = "select subject from sub_master";
	
	
$sql=mysqli_query($conn,"select subject from sub_master");
	while($r=mysqli_fetch_array($sql))
	{
	echo "<option value='".$r['subject']."'>".$r['subject']."</option>";
	}
		 ?>
 </select>
 </td>
 </tr>


 <tr>

<th> Select Faculty::</th>
<td>
<select name="facultyd" class="form-control">
	<?php

	$qstring = "select faculty from sub_master";
	
	
$sql=mysqli_query($conn,"select faculty from sub_master");
	while($r=mysqli_fetch_array($sql))
	{
	echo "<option value='".$r['faculty']."'>".$r['faculty']."</option>";
	}
		 ?>
 </select>
 </td>
 </tr>
				
</table>	
<?php
$que=mysqli_query($conn,"select * from questions ");
	
	$row=mysqli_fetch_array($que)

?>

<h3>HERE YOU GO.....</h3>
<table class="table table-bordered">
<tr>
<?php echo "<td>".$row['question_at']."</td>"; ?>
<td><input type="radio" name="q_1" value="5" required> 5
  <input type="radio" name="q_1" value="4">4
  <input type="radio" name="q_1" value="3"> 3
<input type="radio" name=" q_1" value="2">2
<input type="radio" name="q_1" value="1">1</td>
</tr>
<tr>
<?php 
$row=mysqli_fetch_array($que);
echo "<td>".$row['question_at']."</td>"; ?>
<td><input type="radio" name="q_2" value="5" required> 5
  <input type="radio" name="q_2" value="4">4
  <input type="radio" name="q_2" value="3"> 3
<input type="radio" name=" q_2" value="2">2
<input type="radio" name="q_2" value="1">1</td>
</tr>
<tr>
<?php 
$row=mysqli_fetch_array($que);
echo "<td>".$row['question_at']."</td>"; ?>
<td><input type="radio" name="q_3" value="5" required> 5
  <input type="radio" name="q_3" value="4">4
  <input type="radio" name="q_3" value="3"> 3
<input type="radio" name=" q_3" value="2">2
<input type="radio" name="q_3" value="1">1</td>
</tr>
<tr>
<?php 
$row=mysqli_fetch_array($que);
echo "<td>".$row['question_at']."</td>"; ?>
<td><input type="radio" name="q_4" value="5" required> 5
  <input type="radio" name="q_4" value="4">4
  <input type="radio" name="q_4" value="3"> 3
<input type="radio" name=" q_4" value="2">2
<input type="radio" name="q_4" value="1">1</td>
</tr>
<tr>
<?php 
$row=mysqli_fetch_array($que);
echo "<td>".$row['question_at']."</td>"; ?>
<td><input type="radio" name="q_5" value="5" required> 5
  <input type="radio" name="q_5" value="4">4
  <input type="radio" name="q_5" value="3"> 3
<input type="radio" name=" q_5" value="2">2
<input type="radio" name="q_5" value="1">1</td>
</tr>
<tr>
<?php 
$row=mysqli_fetch_array($que);
echo "<td>".$row['question_at']."</td>"; ?>
<td><input type="radio" name="q_6" value="5" required> 5
  <input type="radio" name="q_6" value="4">4
  <input type="radio" name="q_6" value="3"> 3
<input type="radio" name=" q_6" value="2">2
<input type="radio" name="q_6" value="1">1</td>
</tr>

</table>


<tr>
<td>
<b>suggestion</b><br><br></td>
<td>
<textarea name="sugg" rows="5" cols="60" id="comments" style="font-family:sans-serif;font-size:1.2em;">

</textarea></center><br><br>
<p align="center"><button type="submit" style="font-size:7pt;color:white;background-color:brown;border:2px solid #336600;padding:7px" name="sub">Submitt</button></p></td>

</tr>
</form>
</fieldset>
<


</div><!--close content_item-->
      </div><!--close content-->   
	
	</div><!--close site_content-->  	
  
    
    </div><!--close main-->
  </form>
<center>