

    <!-- Navigation -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header" align="center"><font color="#00FF33">JAWAHAR INSTITUTE OF TECHNOLOGY & MANAGEMENT</font> </h1>
                
            </div>
        </div>
        <!-- /.row -->

        <!-- Intro Content -->
        <div class="row" style="margin-bottom:50px;margin-left:50px">
           
               <P>Hadoop is an open source distributed processing framework that manages data processing and storage for big data applications running in clustered systems. It is at the center of a growing ecosystem of big data technologies that are primarily used to support advanced analytics initiatives, including predictive analytics, data mining and machine learning applications. Hadoop can handle various forms of structured and unstructured data, giving users more flexibility for collecting, processing and analyzing data than relational databases and data warehouses provide
</P> 
               
            </div>
        </div>
        <!-- /.row -->

        <!-- Footer -->
     