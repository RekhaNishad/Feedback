<?php
$conn=mysqli_connect("localhost","root","","feeddb")or die(mysqli_error());
?>