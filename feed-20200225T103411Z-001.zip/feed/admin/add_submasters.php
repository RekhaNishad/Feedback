<?php 
extract($_POST);
include("dbconfig.php");
if(isset($save))
{
$semester=$_POST['s']; 
//echo $semester;
	$subject=$_POST['sb']; 
//	echo $subject;
	$faculty=$_POST['f']; 
//	echo $faculty;
	
$query="insert into sub_master values('$semester','$subject','$faculty')";
$flag = mysqli_query($conn,$query);
if($flag)
  // echo "Inserted succesfully";

$err="<font color='blue'><h3 align='center'> successfull !!<h3></font>";


}




?>


		<div class="row">
		<div class="col-sm-2"></div>
		<div class="col-sm-8">
		<form method="post" enctype="multipart/form-data">
		<table class="table table-bordered" style="margin-bottom:50px">
	<caption><h2 align="center"> Form</h2></caption>
	<Tr>
		<Td colspan="2"><?php echo @$err;?></Td>
	</Tr>
				
				<tr>
					<td>Semester</td>
					<Td><input  type="text" name="s" class="form-control" required/></td>
				</tr>
				<tr>
					<td>Faculty</td>
					<Td><input type="text" name="f" class="form-control" required/></td>
				</tr>
				
				
				<tr>
					<td>Subject </td>
					<Td><input type="text" name="sb" class="form-control" required/></td>
				</tr>
				
				
				
				
				
				
					
				
				<tr>	
<Td colspan="2" align="center">
<input type="submit" value="Save" class="btn btn-info" name="save"/>
<input type="reset" value="Reset" class="btn btn-info"/>
				
					</td>
				</tr>
			</table>
		</form>
		</div>
		<div class="col-sm-2"></div>
		</div>
	</body>
</html>