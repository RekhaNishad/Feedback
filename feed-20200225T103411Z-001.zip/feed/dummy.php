<?php 
session_start();
include('feed/dbconfig.php');
$q= $_SESSION['user'];
if($q=="")
{header('location:../index.php');}
$sql=mysqli_query($conn,"select * from question  ");
$usersq=mysqli_fetch_assoc($sql);
echo $sql;
//print_r($users);
?>